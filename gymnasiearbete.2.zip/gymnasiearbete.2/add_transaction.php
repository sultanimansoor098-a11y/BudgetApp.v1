<?php
session_start();
require "db.php";

if (!isset($_SESSION["user_id"])) {
  header("Location: login.php");
  exit;
}

$type = $_POST["type"] ?? "";
$amount = (int)($_POST["amount"] ?? 0);
$category = trim($_POST["category"] ?? "");

if (($type !== "income" && $type !== "expense") || $amount <= 0 || $category === "") {
  header("Location: projektide.php");
  exit;
}

$userId = (int)$_SESSION["user_id"];

$stmt = $db->prepare("
  INSERT INTO transactions (user_id, type, amount, category)
  VALUES (?, ?, ?, ?)
");
$stmt->execute([$userId, $type, $amount, $category]);

header("Location: projektide.php");
exit;
