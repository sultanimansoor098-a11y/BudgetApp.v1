<?php
session_start();
require "db.php";

/* ===== SKYDDA SIDAN ===== */
if (!isset($_SESSION["user_id"])) {
  header("Location: login.php");
  exit;
}

$userId = (int)$_SESSION["user_id"];
$email  = $_SESSION["email"] ?? "";

/* ===== HÄMTA TRANSAKTIONER ===== */
$stmt = $db->prepare("
  SELECT id, type, amount, category, created_at
  FROM transactions
  WHERE user_id = ?
  ORDER BY id DESC
");
$stmt->execute([$userId]);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* ===== BERÄKNA SALDO ===== */
$saldo = 0;
foreach ($transactions as $t) {
  if ($t["type"] === "income") {
    $saldo += (int)$t["amount"];
  } else {
    $saldo -= (int)$t["amount"];
  }
}
?>
<!DOCTYPE html>
<html lang="sv">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Budget | BudgetApp</title>
  <link rel="stylesheet" href="projektide.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<header>
  <nav>
    <a href="index.php">Hem</a>
    <a href="projektide.php" class="aktiv">Budget</a>
    <a href="om-oss.php">Om oss</a>
    <a href="kontakt.php">Kontakt</a>
    <a href="logout.php">Logga ut</a>
  </nav>
</header>

<main class="container">
  <h1>Min budget</h1>
  <p class="muted">Inloggad som: <strong><?= htmlspecialchars($email) ?></strong></p>

  <?php if (isset($_GET["msg"])): ?>
    <p class="message"><?= htmlspecialchars($_GET["msg"]) ?></p>
  <?php endif; ?>

  <section>
    <h2>Lägg till transaktion</h2>

    <form class="form" method="post" action="add_transaction.php">
      <label for="type">Typ</label>
      <select id="type" name="type" required>
        <option value="income">Inkomst</option>
        <option value="expense">Utgift</option>
      </select>

      <label for="amount">Belopp (kr)</label>
      <input type="number" id="amount" name="amount" min="1" required>

      <label for="category">Kategori</label>
      <input type="text" id="category" name="category" required>

      <button type="submit">Spara</button>
    </form>
  </section>

  <section>
    <h2>Historik</h2>

    <?php if (!$transactions): ?>
      <p class="muted">Inga transaktioner ännu.</p>
    <?php else: ?>
      <ul class="tx-list">
        <?php foreach ($transactions as $t): ?>
          <li>
            <span class="tx-left">
              <?= htmlspecialchars($t["category"]) ?>
              <span class="tx-date"><?= htmlspecialchars(substr($t["created_at"], 0, 10)) ?></span>
            </span>

            <span class="tx-right">
              <span class="<?= $t["type"] === "income" ? "income" : "expense" ?>">
                <?= $t["type"] === "income" ? "+" : "−" ?><?= (int)$t["amount"] ?> kr
              </span>

              <form action="delete_transaction.php" method="post" class="inline-form">
                <input type="hidden" name="id" value="<?= (int)$t["id"] ?>">
                <button type="submit" class="danger" onclick="return confirm('Radera transaktionen?')">
                  Radera
                </button>
              </form>
            </span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <p class="summary">Totalt saldo: <?= (int)$saldo ?> kr</p>
  </section>

  <section>
    <h2>Utgifter per kategori</h2>
    <canvas id="expenseChart"></canvas>
  </section>
</main>

<script>
  // Data från PHP
  const transactions = <?= json_encode($transactions) ?>;

  // Plocka ut bara utgifter och summera per kategori
  const expenseData = {};
  for (const t of transactions) {
    if (t.type === "expense") {
      expenseData[t.category] = (expenseData[t.category] || 0) + Number(t.amount);
    }
  }

  const labels = Object.keys(expenseData);
  const values = Object.values(expenseData);

  // Olika färg per kategori
  const colors = [
    "#3366CC","#DC3912","#FF9900","#109618",
    "#990099","#0099C6","#DD4477","#66AA00",
    "#B82E2E","#316395","#994499","#22AA99"
  ];

  new Chart(document.getElementById("expenseChart"), {
    type: "pie",
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: labels.map((_, i) => colors[i % colors.length])
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: "bottom" } }
    }
  });
</script>

</body>
</html>
