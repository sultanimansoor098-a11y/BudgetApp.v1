<?php
session_start();
require "db.php";

if (!isset($_SESSION["user_id"])) {
  header("Location: login.php");
  exit;
}

$id = (int)($_POST["id"] ?? 0);
$userId = (int)$_SESSION["user_id"];

if ($id <= 0) {
  header("Location: projektide.php");
  exit;
}

/* Viktigt: radera bara om posten tillhör användaren */
$stmt = $db->prepare("DELETE FROM transactions WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $userId]);

header("Location: projektide.php");
exit;
