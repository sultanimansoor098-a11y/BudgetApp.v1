<?php
session_start();
require "db.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $email = trim($_POST["email"] ?? "");
  $password = trim($_POST["password"] ?? "");

  if ($email === "" || $password === "") {
    $message = "Fyll i alla fält.";
  }

  // REGISTRERA
  if (isset($_POST["register"]) && $message === "") {
    $hash = password_hash($password, PASSWORD_DEFAULT);

    try {
      $stmt = $db->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
      $stmt->execute([$email, $hash]);
      $message = "Konto skapat! Du kan nu logga in.";
    } catch (PDOException $e) {
      $message = "Kontot finns redan. Testa att logga in.";
    }
  }

  // LOGGA IN
  if (isset($_POST["login"]) && $message === "") {
    $stmt = $db->prepare("SELECT id, email, password FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user["password"])) {
      $_SESSION["user_id"] = $user["id"];
      $_SESSION["email"] = $user["email"];
      header("Location: projektide.php");
      exit;
    } else {
      $message = "Fel e-post eller lösenord.";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="sv">
<head>
  <meta charset="UTF-8">
  <title>Logga in | BudgetApp</title>
  <link rel="stylesheet" href="projektide.css">
</head>
<body>

<header>
  <nav>
    <a href="index.php">Hem</a>
    <a href="kontakt.php">Kontakt</a>
    <a href="om-oss.php">Om oss</a>
    <a href="login.php" class="aktiv">Logga in</a>
  </nav>
</header>

<main class="container">
  <h1>Logga in</h1>

  <form method="post">
    <label for="email">E-post</label>
    <input type="email" id="email" name="email" required>

    <label for="password">Lösenord</label>
    <input type="password" id="password" name="password" required>

    <button type="submit" name="login">Logga in</button>
    <button type="submit" name="register">Registrera</button>
  </form>

  <?php if ($message): ?>
    <p><?= htmlspecialchars($message) ?></p>
  <?php endif; ?>
</main>

</body>
</html>
