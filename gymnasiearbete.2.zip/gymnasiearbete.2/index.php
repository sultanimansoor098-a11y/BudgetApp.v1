<?php
session_start();
require "db.php";

/*
  Vi räknar saldo + hämtar senaste 3 transaktioner.
  Den här koden funkar både om din DB använder user_id eller user_email.
*/

$isLoggedIn = isset($_SESSION["user_id"]) || isset($_SESSION["email"]);
$email = $_SESSION["email"] ?? "";
$userId = (int)($_SESSION["user_id"] ?? 0);

$saldo = 0;
$preview = [];

if ($isLoggedIn) {
  try {
    // ===== Försök först med user_id (SQLite/MySQL-versioner som använder user_id)
    $stmt = $db->prepare("
      SELECT type, amount, category
      FROM transactions
      WHERE user_id = ?
      ORDER BY id DESC
      LIMIT 3
    ");
    $stmt->execute([$userId]);
    $preview = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $db->prepare("
      SELECT
        COALESCE(SUM(CASE WHEN type='income' THEN amount ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END), 0)
      FROM transactions
      WHERE user_id = ?
    ");
    $stmt->execute([$userId]);
    $saldo = (int)($stmt->fetchColumn() ?? 0);

  } catch (Exception $e) {
    // ===== Fallback: om DB istället har user_email (din gamla SQLite)
    $stmt = $db->prepare("
      SELECT type, amount, category
      FROM transactions
      WHERE user_email = ?
      ORDER BY id DESC
      LIMIT 3
    ");
    $stmt->execute([$email]);
    $preview = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $db->prepare("
      SELECT
        COALESCE(SUM(CASE WHEN type='income' THEN amount ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN type='expense' THEN amount ELSE 0 END), 0)
      FROM transactions
      WHERE user_email = ?
    ");
    $stmt->execute([$email]);
    $saldo = (int)($stmt->fetchColumn() ?? 0);
  }
}
?>
<!DOCTYPE html>
<html lang="sv">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BudgetApp – Hem</title>
  <link rel="stylesheet" href="projektide.css">
</head>
<body>

<header>
  <nav class="hero-nav">
    <div class="logo">BudgetApp</div>

    <div class="menu-links">
      <a href="index.php" class="aktiv">Hem</a>
      <a href="projektide.php">Budget</a>
      <a href="om-oss.php">Om oss</a>
      <a href="kontakt.php" class="cta">Kontakt</a>

      <?php if ($isLoggedIn): ?>
        <a href="logout.php">Logga ut</a>
      <?php else: ?>
        <a href="login.php">Logga in</a>
      <?php endif; ?>
    </div>
  </nav>
</header>

<main>
  <section class="hero">
    <div class="hero-content">
      <h1>Smart ekonomi för studenter</h1>
      <p>
        Få kontroll över dina inkomster och utgifter.
        Följ din ekonomi och skapa bättre vanor.
      </p>

      <div class="hero-buttons">
        <a href="projektide.php" class="primary-btn">Öppna budget</a>
        <a href="kontakt.php" class="secondary-btn">Kontakta oss</a>
      </div>

      <?php if ($isLoggedIn && $email): ?>
        <p class="muted" style="margin-top:14px;">Inloggad som: <strong><?= htmlspecialchars($email) ?></strong></p>
      <?php endif; ?>
    </div>

    <aside class="hero-card">
      <p class="card-title">Totalt saldo</p>
      <h2><?= (int)$saldo ?> kr</h2>

      <?php if (!$isLoggedIn): ?>
        <p class="muted">Logga in för att se din data.</p>
      <?php else: ?>
        <?php if (!$preview): ?>
          <p class="muted">Inga transaktioner ännu.</p>
        <?php else: ?>
          <?php foreach ($preview as $t): ?>
            <?php
              $sign = ($t["type"] === "income") ? "+" : "−";
              $class = ($t["type"] === "income") ? "income" : "expense";
            ?>
            <div class="transaction">
              <span><?= htmlspecialchars($t["category"]) ?></span>
              <span class="<?= $class ?>"><?= $sign . (int)$t["amount"] ?> kr</span>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      <?php endif; ?>
    </aside>
  </section>
</main>

<footer class="footer">
  <p>© 2026 BudgetApp</p>
</footer>

</body>
</html>
